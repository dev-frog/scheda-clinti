# Scheda Clienti - WordPress Plugin

A modern furniture ordering form plugin for WordPress with shortcode support.

## Features

- **Two-step form workflow** with progress indicator
- **Customer information collection**
- **9 product categories** with accordion navigation
- **Dynamic add/remove** product items
- **Conditional fields** based on selections
- **Real-time order summary**
- **AJAX form submission**
- **Email notifications**
- **Admin dashboard** for order management
- **Easy shortcode integration**

## Installation

### Method 1: Manual Upload

1. Download the plugin ZIP file
2. Go to WordPress Admin → Plugins → Add New → Upload Plugin
3. Select the ZIP file and click "Install Now"
4. Activate the plugin

### Method 2: FTP Upload

1. Extract the plugin folder
2. Upload the `scheda-clienti-wordpress` folder to `/wp-content/plugins/`
3. Go to WordPress Admin → Plugins
4. Find "Scheda Clienti - Furniture Order Form" and click "Activate"

## Usage

### Basic Shortcode

Place this shortcode on any page, post, or widget:

```
[scheda_clienti]
```

### With Custom Attributes

```
[scheda_clienti
    title="Custom Title"
    description="Custom Description"
    class="my-custom-class"]
```

### Attributes

- `title` - Form heading (default: "Scheda Clienti")
- `description` - Form subtitle
- `class` - Additional CSS classes for styling

## Admin Panel

After activation, you'll find a new menu item:

**Scheda Orders** → View and manage all submitted orders

### Settings Page

Go to **Scheda Orders → Settings** to configure:

1. **Email Recipient** - Address to receive order notifications
2. **Success Message** - Message shown after successful submission
3. **Email Notifications** - Enable/disable email alerts

### Order Management

Each order contains:

- **Order Number** - Auto-generated (e.g., SC-000123)
- **Customer Details** - Name, email, phone, city, address, notes
- **Order Items** - All selected products with details
- **Order Status** - Pending, Processing, Completed, Cancelled

## Product Categories

The form includes 9 product categories:

1. **Flooring (Package)** - Type, installation method
2. **Interior Doors** - Size, handle, dimensions, installation
3. **Armored Door** - Same as interior doors
4. **Bathroom Furniture** - Name, code, link, transport
5. **Fixtures** - Product details and transport options
6. **Mattresses** - Product-specific fields
7. **Ceramics** - Product-specific fields
8. **Sofas** - Product-specific fields
9. **Children's Bedrooms** - Product-specific fields

## Form Flow

1. **Step 1**: Customer fills in contact information
2. **Validation**: Required fields are validated
3. **Step 2**: Customer selects products from categories
4. **Submission**: Data sent via AJAX to WordPress
5. **Storage**: Order saved as custom post type
6. **Notifications**: Emails sent to admin and customer
7. **Confirmation**: Success message displayed

## Email Notifications

### Admin Notification Email

Includes:
- Order number and date
- Complete customer information
- All order items grouped by category
- Direct link to view order in admin

### Customer Confirmation Email

Includes:
- Order number
- Order summary
- Confirmation message

## Customization

### Styling

The plugin uses CSS classes that can be overridden in your theme:

```css
/* Container */
.scheda-clienti-wrapper { }

/* Loading state */
.sc-loading { }

/* Success message */
.sc-wordpress-success { }
```

### Hook Reference

**Action Hooks:**

```php
// Fires after order is saved
do_action('sc_order_saved', $post_id, $data);
```

**Filter Hooks:**

```php
// Customize columns in orders list
add_filter('manage_scheda_order_posts_columns', function($columns) {
    // Add custom columns
    return $columns;
});
```

## Troubleshooting

### Form Not Loading

1. Check browser console for JavaScript errors
2. Verify assets are loading in network tab
3. Ensure shortcode syntax is correct
4. Check for conflicts with other plugins

### Emails Not Sending

1. Check WordPress email configuration
2. Verify spam folder
3. Test with `wp_mail()` function
4. Check server email logs
4. Ensure SMTP is properly configured on your server

### Orders Not Saving

1. Check WordPress debug log for errors
2. Verify custom post type is registered
3. Check user permissions
4. Ensure database tables are accessible

## Requirements

- **WordPress**: 5.0 or higher
- **PHP**: 7.4 or higher
- **Memory**: 128MB or higher recommended

## Security

- All form data is sanitized before storage
- AJAX requests protected with WordPress nonces
- Output escaped to prevent XSS attacks
- SQL injection prevention via WordPress APIs

## Development

### File Structure

```
scheda-clienti-wordpress/
├── scheda-clienti.php         # Main plugin file
├── includes/
│   ├── class-sc-ajax.php       # AJAX handlers
│   └── class-sc-data.php       # Data management
├── assets/
│   ├── index-CIiFNmIw.css      # React app styles
│   ├── index-DDqDgeVF.js       # React app bundle
│   └── wp-bridge.js            # WordPress bridge script
└── README.md
```

### Building the React App

If you want to modify the React app:

1. Go to the source directory: `../src/`
2. Make your changes
3. Build the app: `npm run build`
4. Copy assets to plugin:
   ```bash
   cp dist/assets/* scheda-clienti-wordpress/assets/
   ```
5. Update filenames in `scheda-clienti.php`

## Support

For issues, questions, or contributions:

1. Check the documentation
2. Review troubleshooting section
3. Check for existing issues
4. Submit new issue with details

## License

GPL v2 or later

## Changelog

### Version 1.0.0
- Initial release
- Two-step form with customer info and product selection
- 9 product categories with dynamic fields
- AJAX form submission
- Email notifications
- Admin dashboard for order management
- Shortcode integration

## Credits

Developed based on the React Scheda Clienti form application.

---

**Thank you for using Scheda Clienti!**
