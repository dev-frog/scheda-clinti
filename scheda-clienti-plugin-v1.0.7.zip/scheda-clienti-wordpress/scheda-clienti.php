<?php
/**
 * Plugin Name: Scheda Clienti - Furniture Quote Form
 * Plugin URI: https://github.com/dev-frog/scheda-clinti
 * Description: A modern furniture quote form plugin for WordPress. Display the form with shortcode [scheda_clienti]
 * Version: 1.0.7
 * Author: dev-frog
 * Author URI: https://dev-frog.github.io/blog
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: scheda-clienti
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('SC_VERSION', '1.0.7');
define('SC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SC_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Scheda Clienti Plugin Class
 */
class Scheda_Clienti_Plugin {

    /**
     * Single instance of the class
     */
    private static $instance = null;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
        $this->includes();
        $this->init_classes();
    }

    /**
     * Initialize WordPress hooks
     */
    private function init_hooks() {
        // Enqueue frontend assets
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);

        // Register shortcode
        add_shortcode('scheda_clienti', [$this, 'render_shortcode']);

        // Register activation/deactivation hooks
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);

        // Load text domain
        add_action('init', [$this, 'load_textdomain']);
    }

    /**
     * Include required files
     */
    private function includes() {
        require_once SC_PLUGIN_DIR . 'includes/class-sc-ajax.php';
        require_once SC_PLUGIN_DIR . 'includes/class-sc-data.php';
        require_once SC_PLUGIN_DIR . 'includes/class-sc-optimization.php';
        require_once SC_PLUGIN_DIR . 'includes/class-sc-settings.php';
    }

    /**
     * Initialize plugin classes
     */
    private function init_classes() {
        // Initialize AJAX handler
        new SC_AJAX_Handler();
        // Initialize data handler
        new SC_Data_Handler();
        // Initialize CSS optimization
        new SC_CSS_Optimization();
        // Initialize settings page
        SC_Settings_Page::get_instance();
    }

    /**
     * Enqueue frontend assets
     */
    public function enqueue_assets() {
        // Only load assets on pages containing our shortcode
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'scheda_clienti')) {

            // Find the latest CSS and JS files dynamically (matches index.js or index-hash.js)
            $css_file = $this->find_asset('assets/index*.css');
            $js_file = $this->find_asset('assets/index*.js');

            if ($css_file) {
                wp_enqueue_style(
                    'scheda-clienti-css',
                    SC_PLUGIN_URL . $css_file,
                    [],
                    SC_VERSION
                );
            }

            if ($js_file) {
                // Enqueue bridge script first
                wp_enqueue_script(
                    'scheda-clienti-bridge',
                    SC_PLUGIN_URL . 'assets/wp-bridge.js',
                    [],
                    SC_VERSION,
                    true
                );

                // Localize script with AJAX URL and nonce to the bridge script
                wp_localize_script('scheda-clienti-bridge', 'scPlugin', [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('sc_ajax_nonce'),
                    'adminEmail' => get_option('admin_email'),
                    'salesEmails' => get_option('sc_sales_emails', [get_option('admin_email')]),
                    'companyName' => get_option('sc_company_name', get_bloginfo('name')),
                    'strings' => [
                        'success' => __('Preventivo inviato con successo!', 'scheda-clienti'),
                        'error' => __('Errore durante l\'invio del modulo. Riprova.', 'scheda-clienti'),
                        'loading' => __('Invio in corso...', 'scheda-clienti')
                    ]
                ]);

                wp_enqueue_script(
                    'scheda-clienti-js',
                    SC_PLUGIN_URL . $js_file,
                    ['scheda-clienti-bridge'], // Depend on bridge
                    SC_VERSION,
                    true // Load in footer
                );

                // Add inline script to ensure proper initialization
                wp_add_inline_script('scheda-clienti-bridge', '
                    console.log("Scheda Clienti: Bridge script loaded");
                    if (typeof scPlugin !== "undefined") {
                        console.log("Scheda Clienti: WordPress config initialized", scPlugin);
                    } else {
                        console.error("Scheda Clienti: scPlugin not available");
                    }
                ', 'after');
            }
        }
    }

    /**
     * Helper to find the latest asset matching a pattern
     */
    private function find_asset($pattern) {
        $files = glob(SC_PLUGIN_DIR . $pattern);
        if (!$files) {
            return false;
        }
        
        // Sort by modification time to get the latest
        usort($files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        
        return str_replace(SC_PLUGIN_DIR, '', $files[0]);
    }

    /**
     * Render shortcode
     *
     * @param array $atts Shortcode attributes
     * @return string Rendered HTML
     */
    public function render_shortcode($atts) {
        $atts = shortcode_atts([
            'title' => __('Scheda Clienti', 'scheda-clienti'),
            'description' => __('Completa il modulo sottostante per effettuare il tuo preventivo di mobili.', 'scheda-clienti'),
            'class' => ''
        ], $atts, 'scheda_clienti');

        ob_start();

        // Trigger action for loading state
        do_action('scheda_clienti_before_render');

        ?>
        <div id="scheda-clienti-root" class="scheda-clienti-wrapper <?php echo esc_attr($atts['class']); ?>"
             data-title="<?php echo esc_attr($atts['title']); ?>"
             data-description="<?php echo esc_attr($atts['description']); ?>">
            <!-- React app will mount here -->
        </div>
        <script>
            // Fallback: hide loading state if no app mounts after 5 seconds
            setTimeout(function() {
                const loadingState = document.getElementById('sc-loading-state');
                const rootElement = document.getElementById('scheda-clienti-root');
                if (loadingState && !rootElement.classList.contains('loaded')) {
                    console.warn('Scheda Clienti: App did not load in time, hiding loading state');
                    loadingState.style.display = 'none';
                    rootElement.classList.add('loaded');
                }
            }, 5000);
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * Plugin activation
     */
    public function activate() {
        // Create custom post type for orders
        $this->create_order_post_type();

        // Flush rewrite rules
        flush_rewrite_rules();

        // Set default options
        $this->set_default_options();
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Create custom post type for orders
     */
    private function create_order_post_type() {
        // This will be called during activation
        // The actual registration happens in SC_Data_Handler
    }

    /**
     * Set default plugin options
     */
    private function set_default_options() {
        $defaults = [
            'sc_email_recipient' => get_option('admin_email'),
            'sc_success_message' => __('Grazie! Il tuo preventivo è stato inviato con successo. Ti contatteremo al più presto.', 'scheda-clienti'),
            'sc_enable_notifications' => '1',
            'sc_sales_emails' => [get_option('admin_email')],
            'sc_email_from_name' => get_bloginfo('name'),
            'sc_email_from_address' => get_option('admin_email'),
            'sc_company_name' => get_bloginfo('name'),
            'sc_company_address' => '',
            'sc_company_phone' => '',
            'sc_company_vat' => ''
        ];

        foreach ($defaults as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }
    }

    /**
     * Load plugin text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain('scheda-clienti', false, dirname(SC_PLUGIN_BASENAME) . '/languages');
    }
}

/**
 * Initialize the plugin
 */
function scheda_clienti_init() {
    return Scheda_Clienti_Plugin::get_instance();
}

// Start the plugin
scheda_clienti_init();

/**
 * Plugin activation helper
 */
register_activation_hook(__FILE__, function() {
    // Register post type during activation
    if (!post_type_exists('scheda_order')) {
        $labels = [
            'name' => __('Preventivi', 'scheda-clienti'),
            'singular_name' => __('Preventivo', 'scheda-clienti'),
            'menu_name' => __('Preventivi', 'scheda-clienti'),
            'add_new' => __('Aggiungi Nuovo', 'scheda-clienti'),
            'add_new_item' => __('Aggiungi Nuovo Preventivo', 'scheda-clienti'),
            'edit' => __('Modifica', 'scheda-clienti'),
            'edit_item' => __('Modifica Preventivo', 'scheda-clienti'),
            'new_item' => __('Nuovo Preventivo', 'scheda-clienti'),
            'view' => __('Visualizza Preventivo', 'scheda-clienti'),
            'view_item' => __('Visualizza Preventivo', 'scheda-clienti'),
            'search_items' => __('Cerca Preventivi', 'scheda-clienti'),
            'not_found' => __('Nessun preventivo trovato', 'scheda-clienti'),
            'not_found_in_trash' => __('Nessun preventivo trovato nel cestino', 'scheda-clienti'),
        ];

        $args = [
            'labels' => $labels,
            'description' => __('Preventivi mobili', 'scheda-clienti'),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'capability_type' => 'post',
            'supports' => ['title'],
            'menu_icon' => 'dashicons-cart',
            'menu_position' => 20,
        ];

        register_post_type('scheda_order', $args);
    }
});
