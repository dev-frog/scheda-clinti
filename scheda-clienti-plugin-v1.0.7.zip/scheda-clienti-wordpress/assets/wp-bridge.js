/**
 * WordPress Bridge Script
 *
 * This script bridges the React app with WordPress AJAX functionality
 * It provides the necessary hooks and data submission handlers
 */

(function() {
    'use strict';

    // Wait for DOM to be ready
    document.addEventListener('DOMContentLoaded', function() {
        // Check if root element exists
        const rootElement = document.getElementById('scheda-clienti-root');
        if (!rootElement) {
            console.warn('Scheda Clienti: Root element not found, waiting for initialization...');
            // Retry after a delay
            setTimeout(function() {
                if (document.getElementById('scheda-clienti-root')) {
                    console.log('Scheda Clienti: Root element found, initializing...');
                    initBridge();
                }
            }, 500);
            return;
        }

        function initBridge() {
            // Get WordPress config from data attributes
            const config = {
                title: rootElement.getAttribute('data-title') || 'Scheda Clienti',
                description: rootElement.getAttribute('data-description') || 'Completa il modulo sottostante per effettuare il tuo preventivo di mobili.'
            };

            // Inject WordPress AJAX handler into window for React app
            window.wordpressConfig = config;
        }

        initBridge();

        /**
         * WordPress Form Submission Handler
         */
        window.submitToWordPress = function(formData) {
            return new Promise((resolve, reject) => {
                // Check if scPlugin is available (localized from WordPress)
                if (typeof scPlugin === 'undefined') {
                    console.error('Scheda Clienti: WordPress plugin not initialized');
                    reject(new Error('WordPress plugin not initialized'));
                    return;
                }

                // Prepare AJAX request
                const xhr = new XMLHttpRequest();
                xhr.open('POST', scPlugin.ajaxUrl, true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

                xhr.onload = function() {
                    if (xhr.status >= 200 && xhr.status < 300) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            if (response.success) {
                                resolve(response.data);
                            } else {
                                reject(new Error(response.data.message || 'Invio fallito'));
                            }
                        } catch (e) {
                            reject(new Error('Risposta non valida dal server'));
                        }
                    } else {
                        reject(new Error('Errore del server: ' + xhr.status));
                    }
                };

                xhr.onerror = function() {
                    reject(new Error('Errore di rete'));
                };

                // Prepare form data
                const params = new URLSearchParams();
                params.append('action', 'sc_submit_form');
                params.append('nonce', scPlugin.nonce);
                params.append('form_data', JSON.stringify(formData));

                console.log('Scheda Clienti: Submitting form to WordPress...');
                xhr.send(params.toString());
            });
        };

        /**
         * Show WordPress success message
         */
        window.showWordPressSuccess = function() {
            const successDiv = document.createElement('div');
            successDiv.className = 'sc-wordpress-success';
            successDiv.style.cssText = `
                padding: 20px;
                background: #d1fae5;
                border-radius: 8px;
                color: #065f46;
                margin-top: 20px;
                text-align: center;
            `;
            successDiv.textContent = scPlugin?.strings?.success || 'Preventivo inviato con successo!';

            // Hide loading message
            const loadingDiv = rootElement.querySelector('.sc-loading');
            if (loadingDiv) {
                loadingDiv.style.display = 'none';
            }

            // Append success message
            rootElement.appendChild(successDiv);

            // Reset form after 3 seconds
            setTimeout(function() {
                successDiv.remove();
                if (loadingDiv) {
                    loadingDiv.style.display = 'block';
                }
                // Trigger form reset via custom event
                window.dispatchEvent(new CustomEvent('scResetForm'));
            }, 3000);
        };

        // Remove loading message once React app mounts
        window.addEventListener('scAppMounted', function() {
            console.log('Scheda Clienti: App mounted, removing loading state');

            // Remove loading state
            const loadingState = document.getElementById('sc-loading-state');
            if (loadingState) {
                loadingState.style.display = 'none';
            }

            // Show the app content
            if (rootElement) {
                rootElement.classList.add('loaded');
            }
        });
    });
})();
